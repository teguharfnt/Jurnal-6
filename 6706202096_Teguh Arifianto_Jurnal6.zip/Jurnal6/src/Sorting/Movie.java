package Sorting;

class Movie implements Comparable<Movie> {
    // Atribut dengan access modifier private
    private double rating;
    private String name;
    private int year;

    // fungsi untuk memanggil atribut yaitu rating, name, dan year
    public Movie(double rating, String name, int year) {
        this.rating = rating;
        this.name = name;
        this.year = year;
    }

    // fungsi untuk mendapatkan rating
    public double getRating() {
        return rating;
    }

    // fungsi untuk mendapatkan nama
    public String getName() {
        return name;
    }

    // fungsi untuk mendapatkan tahun
    public int getYear() {
        return year;
    }

    // fungsi untuk meng-komper data kedalam objek
    @Override
    public int compareTo(Movie o) {
        return this.getYear() - o.getYear();
    }
}

